# plastico-contaminacion

PlasticScan – Simulador educativo de dispersión de partículas en plásticos.

Contenido:
- index.html : interfaz y simulador.

Diseñado para publicarse con GitHub Pages (branch `main`, root).
URL esperada tras publicar: https://tomasblanco12.github.io/plastico-contaminacion/